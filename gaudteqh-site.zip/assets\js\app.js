// Minimal interactive behavior for the static site
document.addEventListener('DOMContentLoaded',()=>{
  const form=document.getElementById('contactForm');
  if(form){
    form.addEventListener('submit',e=>{
      e.preventDefault();
      // Fake submit for now — in production wire to an endpoint (Netlify Forms, Formspree, etc.)
      form.reset();
      document.getElementById('success').classList.remove('hidden');
      setTimeout(()=>document.getElementById('success').classList.add('hidden'),4000);
    });
  }
});
